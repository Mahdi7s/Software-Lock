﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using TS7S.Base;

namespace SabaMediaLock.Utilities
{
    public enum CryptoAlgorithm { AES, DES, Rijndael, RijndaelManaged }

    public class FileEncryptor
    {
        protected readonly string _key;
        protected readonly byte[] _keyMd5;

        public FileEncryptor(string key, int bufferSize = 6*1024)
        {
            BufferSize = bufferSize;

            _key = key;
            _keyMd5 = key.Md5();
        }

        public int BufferSize { get; protected set; }

        public void AesEncrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.AES), srcPath, desPath);                                             
        }

        public void AesDecrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.AES, false), srcPath, desPath);
        }

        public void DesEncrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.DES), srcPath, desPath);
        }

        public void DesDecrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.DES, false), srcPath, desPath);
        }

        public void RijndaelEncrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.Rijndael), srcPath, desPath);
        }

        public void RijndaelDecrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.Rijndael, false), srcPath, desPath);
        }

        public void RijndaelManagedEncrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.RijndaelManaged), srcPath, desPath);
        }

        public void RijndaelManagedDecrypt(string srcPath, string desPath)
        {
            EncryptOrDecryptFile(GetCryptoTransform(CryptoAlgorithm.RijndaelManaged, false), srcPath, desPath);
        }

        public virtual byte[] EncryptOrDecryptFile(ICryptoTransform transform, string srcPath)
        {
            using (var srcStrm = File.OpenRead(srcPath))
            {
                using (var memStrm = new MemoryStream())
                {
                    EncryptOrDecryptFile(transform, srcStrm, memStrm);
                    //memStrm.
                    return memStrm.ToArray();
                }
            }
        }

        public virtual void EncryptOrDecryptFile(ICryptoTransform transform, string srcPath, string desPath)
        {
            using (var srcStrm = File.OpenRead(srcPath))
            {
                using (var desStrm = new FileStream(desPath, FileMode.OpenOrCreate, FileAccess.Write))
                {
                    EncryptOrDecryptFile(transform, srcStrm, desStrm);
                }
            }
        }

        public virtual void EncryptOrDecryptFile(ICryptoTransform transform, Stream srcStream, Stream desStream)
        {
            using (var bs = new BufferedStream(srcStream, BufferSize))
            {
                using (var dcs = new CryptoStream(desStream, transform, CryptoStreamMode.Write))
                {
                    using (var bcs = new BufferedStream(dcs, BufferSize))
                    {
                        int readBytesCount = 0;
                        var buffer = new byte[BufferSize];

                        while ((readBytesCount = bs.Read(buffer, 0, BufferSize)) > 0)
                        {
                            bcs.Write(buffer, 0, readBytesCount);
                        }
                        //bcs.Flush();
                        //dcs.FlushFinalBlock();
                    }
                }
            }
        }

        public virtual ICryptoTransform GetCryptoTransform(CryptoAlgorithm algorithm, bool encrypt = true)
        {
            SymmetricAlgorithm sym = null;
            switch (algorithm)
            {
                case CryptoAlgorithm.AES:
                    sym = Aes.Create();
                    //sym.Padding = PaddingMode.PKCS7;
                    sym.Padding = PaddingMode.None;
                    if(!encrypt)
                        return sym.CreateDecryptor(_keyMd5, _keyMd5);
                    return sym.CreateEncryptor(_keyMd5, _keyMd5);
                case CryptoAlgorithm.DES:
                    sym = DES.Create();
                    sym.Padding = PaddingMode.PKCS7;
                    if (!encrypt)
                        return sym.CreateDecryptor(_keyMd5.Take(8).ToArray(), _keyMd5.Skip(8).ToArray());
                    return sym.CreateEncryptor(_keyMd5.Take(8).ToArray(), _keyMd5.Skip(8).ToArray());
                case CryptoAlgorithm.Rijndael: 
                    sym = Rijndael.Create();
                    sym.Padding = PaddingMode.PKCS7;
                    if(!encrypt)
                        return sym.CreateDecryptor(_keyMd5, _keyMd5);
                    return sym.CreateEncryptor(_keyMd5, _keyMd5);
                case CryptoAlgorithm.RijndaelManaged:
                    sym = RijndaelManaged.Create();
                    sym.Padding = PaddingMode.PKCS7;
                    if(!encrypt)
                        return sym.CreateDecryptor(_keyMd5, _keyMd5);
                    return sym.CreateEncryptor(_keyMd5, _keyMd5);
                default:
                    goto case CryptoAlgorithm.AES;
            }
        }
    }
}
